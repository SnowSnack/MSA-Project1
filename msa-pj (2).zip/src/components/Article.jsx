import { Link, Outlet } from "react-router-dom";
import "../css/Article.css";
// import './'
const Article = () => {
  return (
    <div>
      <section className="se1">
        <article className="art1">
          <ul>
            <li>
              <Link to="./home">Home</Link>
              <Link to="./test">Test</Link>
            </li>
          </ul>
          <Outlet />
        </article>
      </section>
    </div>
  );
};

export default Article;
